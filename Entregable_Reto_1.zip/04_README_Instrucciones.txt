INSTRUCCIONES DE ENTREGA - RETO 1

CONTENIDO DEL ENTREGABLE

Este paquete de entrega contiene los siguientes elementos:

Reto1_Entregables_EinarEscobar/
├── 01_Codigo_Fuente/
│   └── enlace_github.txt
├── 02_Reportes_Serenity/
│   └── serenity.zip
├── 03_Postman/
│   └── Reto1 - ReqRes API.postman_collection.json
└── 04_Instrucciones/
    └── README_Isntrucciones.txt

1. CODIGO FUENTE DEL PROYECTO

El código fuente se encuentra publicado en GitHub en el siguiente repositorio:

https://github.com/eescobar0607/Reto-1-BDG

Se recomienda revisar el archivo README.md principal del repositorio para conocer la estructura interna del proyecto y el detalle técnico de la solución.

2. INFORMES GENERADOS POR SERENITY BDD

En la carpeta:

02_Reportes_Serenity/

se adjunta el archivo comprimido:

serenity.zip

COMO VISUALIZAR EL REPORTE

1. Descomprimir el archivo serenity.zip.
2. Abrir la carpeta extraída.
3. Ejecutar en cualquier navegador el archivo:

index.html

QUE SE PUEDE VALIDAR EN EL REPORTE

Dentro del reporte de Serenity se puede revisar:

- resultados generales de ejecución
- features ejecutadas
- cantidad de escenarios
- porcentaje de éxito
- estadísticas de ejecución
- detalle de los escenarios automatizados

3. COLECCION DE POSTMAN

En la carpeta:

03_Postman/

se encuentra la colección exportada:

Reto1 - ReqRes API.postman_collection.json

QUE CONTIENE ESTA COLECCION

La colección incluye los endpoints mapeados y probados manualmente para el Reto 1:

1. Listar usuarios
2. Registrar usuario exitosamente
3. Registrar usuario sin contraseña
4. Actualizar usuario
5. Eliminar usuario

COMO EJECUTARLA EN POSTMAN

1. Abrir Postman.
2. Seleccionar Import.
3. Cargar el archivo:

Reto1 - ReqRes API.postman_collection.json

4. Verificar o configurar las variables necesarias, especialmente:
   - baseUrl
   - apiKey

Nota: la API de ReqRes requiere una API key válida en el header x-api-key.

4. COMO EJECUTAR LAS PRUEBAS DE AUTOMATIZACION

Una vez descargado el código fuente del repositorio, se puede ejecutar la automatización desde la raíz del proyecto.

REQUISITOS PREVIOS

- Java 17 o superior
- Gradle (o uso del wrapper del proyecto)
- conexión a Internet
- una API key válida de ReqRes configurada en ApiConfig.java

COMANDOS PRINCIPALES

Validar compilación del proyecto:

.\gradlew.bat clean testClasses

Ejecutar la suite automatizada:

.\gradlew.bat clean test

Ejecutar la suite y generar reportes Serenity:

.\gradlew.bat clean test aggregate

5. ESCENARIOS AUTOMATIZADOS EN EL PROYECTO

El proyecto automatiza los siguientes escenarios:

1. Listar usuarios
   - valida código HTTP 200
   - valida que la respuesta contenga usuarios

2. Registrar usuario exitosamente
   - valida código HTTP 200
   - valida presencia de id y token

3. Registrar usuario sin contraseña
   - valida código HTTP 400
   - valida mensaje Missing password

4. Actualizar usuario existente
   - valida código HTTP 200
   - valida name, job y updatedAt

5. Eliminar usuario existente
   - valida código HTTP 204
   - valida body vacío

6. OBSERVACIONES IMPORTANTES

- El proyecto utiliza Serenity BDD, Cucumber, JUnit 5, Gradle y el patrón Screenplay.
- La ejecución puede depender de la estabilidad de la red y de la conectividad hacia la API de ReqRes.
- Si se presentan errores relacionados con autenticación, verificar la API key configurada en ApiConfig.java.

7. RECOMENDACION DE REVISION

Para revisar el entregable de forma ordenada, se sugiere seguir esta secuencia:

1. Revisar el repositorio de GitHub.
2. Abrir la colección de Postman.
3. Ejecutar o revisar la suite automatizada.
4. Abrir el reporte de Serenity BDD.

AUTOR

Einar Andres Escobar Gallo
Reto 1 - Automatización de Servicios
